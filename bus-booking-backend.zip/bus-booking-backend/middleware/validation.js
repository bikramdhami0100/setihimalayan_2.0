import Joi from 'joi';
import { errorResponse } from '../utils/response.js';

/**
 * Generic validation middleware using Joi schema
 * @param {Joi.Schema} schema - Joi validation schema
 * @returns {Function} Express middleware
 */
export const validate = (schema) => {
    return (req, res, next) => {
        const { error } = schema.validate(req.body, { abortEarly: false });
        if (error) {
            const errors = error.details.map(detail => detail.message);
            const fields = {};
            error.details.forEach(detail => {
                const field = detail.path.join('.');
                fields[field] = detail.message;
            });
            return res.status(400).json({
                success: false,
                message: 'Validation error',
                errors,
                fields
            });
        }
        next();
    };
};

// ------------------- User Schemas -------------------
export const createUserSchema = Joi.object({
    email: Joi.string().email().required(),
    phone: Joi.string().pattern(/^[0-9]{10}$/).allow('', null).optional(),
    full_name: Joi.string().min(2).max(100).required(),
    password: Joi.string().min(6).required(),
    role: Joi.string().valid('passenger', 'admin', 'super_admin').default('passenger'),
    status: Joi.string().valid('active', 'inactive', 'suspended').default('active'),
    date_of_birth: Joi.date().allow(null).optional(),
    address: Joi.string().allow('', null).optional(),
    city: Joi.string().allow('', null).optional(),
    state: Joi.string().allow('', null).optional(),
    country: Joi.string().allow('', null).optional(),
    postal_code: Joi.string().allow('', null).optional()
});

export const updateUserSchema = Joi.object({
    email: Joi.string().email().optional(),
    phone: Joi.string().pattern(/^[0-9]{10}$/).allow('', null).optional(),
    full_name: Joi.string().min(2).max(100).optional(),
    password: Joi.string().min(6).allow('').optional(),
    role: Joi.string().valid('passenger', 'admin', 'super_admin').optional(),
    status: Joi.string().valid('active', 'inactive', 'suspended').optional(),
    date_of_birth: Joi.date().allow(null).optional(),
    address: Joi.string().allow('', null).optional(),
    city: Joi.string().allow('', null).optional(),
    state: Joi.string().allow('', null).optional(),
    country: Joi.string().allow('', null).optional(),
    postal_code: Joi.string().allow('', null).optional()
});

// ------------------- Auth Schemas -------------------
export const registerSchema = Joi.object({
    email: Joi.string().email().required(),
    phone: Joi.string().pattern(/^[0-9]{10}$/).required(),
    full_name: Joi.string().min(3).max(100).required(),
    password: Joi.string().min(6).required(),
    role: Joi.string().valid('passenger', 'admin').default('passenger')
});

export const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required()
});

export const sendOtpSchema = Joi.object({
    phone: Joi.string().pattern(/^[0-9]{7,15}$/).required()
});

export const verifyOtpSchema = Joi.object({
    phone: Joi.string().pattern(/^[0-9]{7,15}$/).required(),
    otp: Joi.string().length(6).pattern(/^[0-9]{6}$/).required()
});

export const roleUpdateSchema = Joi.object({
    role: Joi.string().valid('passenger', 'admin', 'super_admin').required()
});

export const changePasswordSchema = Joi.object({
    email: Joi.string().email().optional(),
    newPassword: Joi.string().min(6).required(),
});

export const resetPasswordRequestSchema = Joi.object({
    email: Joi.string().email().required()
});

export const resetPasswordSchema = Joi.object({
    token: Joi.string().required(),
    newPassword: Joi.string().min(6).required(),
    confirmPassword: Joi.string().valid(Joi.ref('newPassword')).required()
});

// ------------------- Bus Schemas -------------------
export const busSchema = Joi.object({
    bus_number: Joi.string().required(),
    registration_number: Joi.string().allow('', null).optional(),
    total_seats: Joi.number().integer().min(10).max(80).required(),
    seat_layout: Joi.object().required(),
    amenities: Joi.array().items(Joi.string()).optional(),
    bus_type: Joi.string().valid('Standard', 'Luxury', 'Sleeper', 'Mini').default('Standard'),
    status: Joi.string().valid('active', 'maintenance', 'retired', 'inactive').default('active'),
    manufacturer: Joi.string().allow(null).optional(),
    model: Joi.string().allow(null).optional(),
    year: Joi.number().integer().min(1990).max(new Date().getFullYear()).allow(null).optional(),
    color: Joi.string().allow(null).optional(),
    license_plate: Joi.string().allow(null).optional(),
    insurance_expiry: Joi.date().allow(null).optional(),
    fitness_expiry: Joi.date().allow(null).optional(),
    notes: Joi.string().allow(null).optional()
});

export const busUpdateSchema = Joi.object({
    bus_number: Joi.string().optional(),
    registration_number: Joi.string().optional(),
    total_seats: Joi.number().integer().min(10).max(80).optional(),
    seat_layout: Joi.object().optional(),
    amenities: Joi.array().items(Joi.string()).optional(),
    bus_type: Joi.string().valid('Standard', 'Luxury', 'Sleeper', 'Mini').optional(),
    status: Joi.string().valid('active', 'maintenance', 'retired', 'inactive').optional(),
    manufacturer: Joi.string().allow(null).optional(),
    model: Joi.string().allow(null).optional(),
    year: Joi.number().integer().min(1990).max(new Date().getFullYear()).allow(null).optional(),
    color: Joi.string().allow(null).optional(),
    license_plate: Joi.string().allow(null).optional(),
    insurance_expiry: Joi.date().allow(null).optional(),
    fitness_expiry: Joi.date().allow(null).optional(),
    notes: Joi.string().allow(null).optional()
});

// ------------------- Route Schemas -------------------
export const routeSchema = Joi.object({
    origin: Joi.string().required(),
    destination: Joi.string().required(),
    distance_km: Joi.number().positive().optional(),
    duration_minutes: Joi.number().integer().positive().optional(),
    base_price: Joi.number().positive().required(),
    stops: Joi.array().items(Joi.object({
        location: Joi.string().required(),
        arrival_time: Joi.date().optional(),
        departure_time: Joi.date().optional(),
        stop_order: Joi.number().integer().optional()
    })).optional(),
    description: Joi.string().optional(),
    route_image: Joi.string().uri().optional()
});

export const routeUpdateSchema = Joi.object({
    origin: Joi.string().optional(),
    destination: Joi.string().optional(),
    distance_km: Joi.number().positive().optional(),
    duration_minutes: Joi.number().integer().positive().optional(),
    base_price: Joi.number().positive().optional(),
    stops: Joi.array().items(Joi.object()).optional(),
    description: Joi.string().optional(),
    is_active: Joi.boolean().optional(),
    route_image: Joi.string().uri().optional()
});

// ------------------- Schedule Schemas -------------------
export const scheduleSchema = Joi.object({
    bus_id: Joi.number().integer().required(),
    route_id: Joi.number().integer().required(),
    departure_time: Joi.date().required(),
    arrival_time: Joi.date().greater(Joi.ref('departure_time')).required(),
    base_price: Joi.number().positive().required(),
    total_seats: Joi.number().integer().min(1).optional(),
    available_seats: Joi.number().integer().min(0).optional(),
    status: Joi.string().valid('scheduled', 'active', 'completed', 'cancelled', 'delayed').optional(),
    delay_minutes: Joi.number().integer().min(0).optional(),
    driver_name: Joi.string().allow('', null).optional(),
    driver_phone: Joi.string().pattern(/^[0-9]{7,15}$/).allow('', null).optional(),
    conductor_name: Joi.string().allow('', null).optional(),
    conductor_phone: Joi.string().pattern(/^[0-9]{7,15}$/).allow('', null).optional(),
    notes: Joi.string().allow('', null).optional()
});

export const scheduleUpdateSchema = Joi.object({
    departure_time: Joi.date().optional(),
    arrival_time: Joi.date().optional(),
    base_price: Joi.number().positive().optional(),
    total_seats: Joi.number().integer().min(1).optional(),
    available_seats: Joi.number().integer().min(0).optional(),
    status: Joi.string().valid('scheduled', 'active', 'completed', 'cancelled', 'delayed').optional(),
    delay_minutes: Joi.number().integer().min(0).optional(),
    driver_name: Joi.string().allow('', null).optional(),
    driver_phone: Joi.string().pattern(/^[0-9]{7,15}$/).allow('', null).optional(),
    conductor_name: Joi.string().allow('', null).optional(),
    conductor_phone: Joi.string().pattern(/^[0-9]{7,15}$/).allow('', null).optional(),
    notes: Joi.string().allow('', null).optional()
});

// ------------------- Booking Schemas -------------------
// export const bookingSchema = Joi.object({
//     schedule_id: Joi.number().integer().required(),
//     selected_seats: Joi.array().items(Joi.string()).min(1).required(),
//     passenger_details: Joi.object({
//         name: Joi.string().required(),
//         age: Joi.number().integer().min(1).max(120).optional(),
//         gender: Joi.string().valid('M', 'F', 'Other').optional(),
//         email: Joi.string().email().optional(),
//         phone: Joi.string().pattern(/^[0-9]{10}$/).optional()
//     }).required(),
//     special_requests: Joi.string().allow('').optional()
// });
export const bookingSchema = Joi.object({
  schedule_id: Joi.number().integer().required(),

  selected_seats: Joi.array()
    .items(Joi.string())
    .min(1)
    .required(),

  passenger_details: Joi.array()
    .items(
      Joi.object({
        seat_number: Joi.string().required(),

        name: Joi.string().required(),

        age: Joi.number().integer().min(1).max(120).optional(),

        gender: Joi.string()
          .valid('Male', 'Female', 'Other') // match your request
          .optional(),

        email: Joi.string().email().optional(),

        phone: Joi.string().pattern(/^[0-9]{10}$/).optional()
      })
    )
    .min(1)
    .required(),

  special_requests: Joi.string().allow('').optional()
});

export const cancelBookingSchema = Joi.object({
    cancellation_reason: Joi.string().required()
});

// Admin booking CRUD schemas
export const adminBookingCreateSchema = Joi.object({
    user_id: Joi.number().integer().optional().allow(null),
    schedule_id: Joi.number().integer().required(),
    seats: Joi.number().integer().min(1).optional(),
    seat_numbers: Joi.array().items(Joi.string()).optional(),
    fare: Joi.number().positive().optional().allow(null),
    discount: Joi.number().min(0).optional().allow(null),
    total_amount: Joi.number().positive().optional().allow(null),
    payment_method: Joi.string().valid('cash', 'card', 'online', 'bank_transfer', 'other').optional(),
    payment_status: Joi.string().valid('unpaid', 'paid', 'refunded', 'partial_refund', 'pending').optional(),
    status: Joi.string().valid('pending_payment', 'confirmed', 'cancelled', 'expired', 'refunded').optional(),
    notes: Joi.string().allow('', null).optional(),
    boarding_point: Joi.string().allow('', null).optional(),
    dropping_point: Joi.string().allow('', null).optional()
});

export const adminBookingUpdateSchema = Joi.object({
    schedule_id: Joi.number().integer().optional(),
    seats: Joi.number().integer().min(1).optional(),
    seat_numbers: Joi.array().items(Joi.string()).optional(),
    fare: Joi.number().positive().optional().allow(null),
    discount: Joi.number().min(0).optional().allow(null),
    total_amount: Joi.number().positive().optional().allow(null),
    payment_method: Joi.string().valid('cash', 'card', 'online', 'bank_transfer', 'other').optional(),
    payment_status: Joi.string().valid('unpaid', 'paid', 'refunded', 'partial_refund', 'pending').optional(),
    status: Joi.string().valid('pending_payment', 'confirmed', 'cancelled', 'expired', 'refunded').optional(),
    notes: Joi.string().allow('', null).optional(),
    boarding_point: Joi.string().allow('', null).optional(),
    dropping_point: Joi.string().allow('', null).optional(),
    passenger_name: Joi.string().allow('', null).optional(),
    passenger_phone: Joi.string().allow('', null).optional()
});

// ------------------- Payment Schemas -------------------
export const paymentInitiateSchema = Joi.object({
    booking_id: Joi.number().integer().required(),
    gateway: Joi.string().valid('esewa', 'khalti', 'connectips').required()
});

// ------------------- Report Schemas -------------------
export const dateRangeSchema = Joi.object({
    start_date: Joi.date().required(),
    end_date: Joi.date().min(Joi.ref('start_date')).required()
});